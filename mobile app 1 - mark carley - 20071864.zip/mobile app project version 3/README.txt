Name: Mark Carley
Student No. 20071864

youtube link: 

Functionality:

From assignment 1 the user should see a 3 second splash screen before been navigated to the main menu. From the main page
a dropdown menu will appear with three options, the first is the back home button which returns the user back to the original point.
The tables activity will show basic data such as name, country, times and the listing activity is the page for both the add
and remove method.

UX/DX:

In this app i decided a menu on the top right hand corner with the corresponding sysmbol will allow the user to navigate
any where from the app.

References:

Dropdown menu
https://youtu.be/oh4YOj9VkVE

Splashscreen:
https://stackoverflow.com/questions/5486789/how-do-i-make-a-splash-screen

Table:
https://stackoverflow.com/questions/33995938/how-to-create-a-table-by-using-tablelayout-in-android-studio

Add and Remove List:
https://youtu.be/ed967ZsQ19o
https://youtu.be/UnyKFgD7_yo

Login & Registration (CODE NOT FINISHED, FOR ASSIGNMENT 2):
https://youtu.be/lF5m4o_CuNg
https://youtu.be/pFc59hCnbPQ
https://youtu.be/zKBGjGoeid0